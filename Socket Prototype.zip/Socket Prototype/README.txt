IMPORTANT: Change the "info" file in this folder to have the ip of the system that the client is communicating with.
	The number at the top of the info file is the port that both of the processes will use.

To run: Open in Qt on two machines. *****Make sure to run the program in the console not the Qt command line*******
	Run the program on both machines, and select one as the client, and one as the server.
	The messages will now be sent

Thanks :)
-Hexadecimal!!!
