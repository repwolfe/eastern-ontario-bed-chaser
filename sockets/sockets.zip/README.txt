IMPORTANT: Change the "info" file in this folder to have the ips of the systems involved. 
The first ip should state it is computer #1 when the program starts. 
The second ip should state it is computer #2 when the program starts.

The number at the top of the info file is the port that both of the processes will use.

To run: Open in Qt on two machines. *****Make sure to run the program in the console not the Qt command line*******
	Run the program on both machines, enter which computer number you are on. 
	The messages will now be sent / received

Thanks :)
-Hexadecimal!!!
